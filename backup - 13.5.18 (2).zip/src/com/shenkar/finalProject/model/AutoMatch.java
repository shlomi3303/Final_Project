package com.shenkar.finalProject.model;

public class AutoMatch extends Match {

	public AutoMatch() {
		// TODO Auto-generated constructor stub
	}

	public AutoMatch(int offerId, int applicationID, boolean offerAproved, boolean applicationAproved, String status,
			int tTL) {
		super();
		// TODO Auto-generated constructor stub
	}

}
