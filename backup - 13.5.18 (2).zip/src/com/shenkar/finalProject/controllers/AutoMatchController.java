package com.shenkar.finalProject.controllers;

import java.util.List;

import com.shenkar.finalProject.model.Application;
import com.shenkar.finalProject.model.Offer;

public class AutoMatchController 
{
	
	Offer offer;
	Application app;
	
	
	public void ranking(Application application, List <Offer> offer)
	{
		
	}

	
}
